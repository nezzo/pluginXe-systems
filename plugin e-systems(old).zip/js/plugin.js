//скрипты всего плагина

jQuery(document).ready(function(){
  
 //дата рождения 
 jQuery('#data_born').datepicker({
  dateFormat : 'dd.mm.yy',
   lang:'ru',
 });
 
  
});